TESTING=ya  ./node_modules/.bin/sls package --stage dev --yahoo hi --region us-east-1 --number 1234
