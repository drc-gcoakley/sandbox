let first = require('./first-layered.js')
let second = require('./second-layered.js')

first.goServerless();
second.goServerless();

