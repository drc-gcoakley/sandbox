An application that tests using the DRC logging stream to ELK.
