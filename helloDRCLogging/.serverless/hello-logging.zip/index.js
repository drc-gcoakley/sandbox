let first = require('./first-logging.js');
let second = require('./second-logging.js');

first.goServerless();
second.goServerless();

